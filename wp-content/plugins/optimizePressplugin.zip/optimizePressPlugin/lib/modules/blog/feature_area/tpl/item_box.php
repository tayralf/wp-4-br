
	<div class="op-bsw-grey-panel section-<?php echo $style_name ?>">
		<div class="op-bsw-grey-panel-header cf">
			<h3><a href="#"><?php echo $title ?></a></h3>
				
			<div class="op-bsw-panel-controls cf">
				<div class="show-hide-panel"><a href="#"></a></div>
			</div>
		</div>
        <?php echo $content ?>
    </div>