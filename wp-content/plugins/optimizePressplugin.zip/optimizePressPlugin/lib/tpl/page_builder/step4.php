<?php echo $this->load_tpl('page_builder/header'); ?>
	<div class="op-bsw-grey-panel op-bsw-grey-panel-fixed">
		<?php echo $content; ?>
	</div>
<?php echo $this->load_tpl('page_builder/footer'); ?>