<div id="launch_suite_pages"><?php echo $stages ?></div>
<div id="launch_suite_add_section-container"><a href="#add_funnel" id="launch_suite_add_section" "><img src="<?php echo OP_IMG ?>live_editor/add_new.png" alt="<?php _e('Add section',OP_SN) ?>" /><span><?php _e('Add New Funnel Stage',OP_SN) ?></span></a></div>
<div id="launch_suite_sales"><?php echo $sales_page ?></div>