<div class="op-bsw-grey-panel-content op-bsw-grey-panel-no-sidebar cf">        
    <label for="op_sections_email_marketing_services_campaignmonitor_api_key" class="form-title"><?php _e('Campaign Monitor API key', OP_SN); ?></label>
    <p class="op-micro-copy"><?php _e('Copy Campaign Monitor API key here.', OP_SN); ?></p>
    <?php op_text_field('op[sections][email_marketing_services][campaignmonitor_api_key]', op_get_option('campaignmonitor_api_key')); ?>
</div>