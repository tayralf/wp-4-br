<div id="<?php echo $id; ?>" class="affiliate-page-banner">
    <textarea><?php echo $embed_code; ?></textarea>
</div>