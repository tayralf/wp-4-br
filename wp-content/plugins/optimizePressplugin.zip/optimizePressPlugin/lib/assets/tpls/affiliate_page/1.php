<div id="<?php echo $id; ?>" class="affiliate-page-banner ">
    <a href="<?php echo $affiliate_link; ?>">
            <img src="<?php echo $image; ?>" />
            <span><?php echo $description; ?></span>
    </a>
    <textarea><a href="<?php echo $affiliate_link; ?>"><img src="<?php echo $image; ?>" /></a></textarea>
</div>