<div class="styled-hr hr-style-0">
    <div class="hr-2">
        <hr />
    </div>
</div>