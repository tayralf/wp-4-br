<div class="styled-hr hr-style-3">
    <img src="<?php echo $path; ?>ornament-3.png" alt="shadow-ornament" width="79" height="27" class="ornament" />
    <hr />
</div>