<div class="styled-hr hr-style-8">
    <div class="hr-1">
    </div>
    <div class="hr-2">
        <hr />
    </div>
</div>