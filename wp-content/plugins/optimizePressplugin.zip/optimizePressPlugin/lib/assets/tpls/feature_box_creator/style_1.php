<?php include ('style.inc.php'); ?>

<div id="<?php echo $id; ?>" class="feature-box-creator feature-box-creator-style-1"<?php echo $block_styles; ?>>
    <div class="feature-box-content cf"<?php echo $content_styles; ?>><?php echo $content; ?></div>
</div>