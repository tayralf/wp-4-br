<script type="text/javascript" src="http://assets.pinterest.com/js/pinit.js" data-pin-build="parsePinBtns"></script>
<script>
<?php // We want to reparse pin buttons after liveeditor insert (or other JS trickery) ?>
if (typeof window.parsePinBtns === 'function') {
    window.parsePinBtns();
}
</script>