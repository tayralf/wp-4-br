<div id="<?php echo $id; ?>" data-counter="false" class="social-sharing social-sharing-horizontal">
    <?php echo $fb_html; ?>
    <?php echo $twitter_html; ?>
    <?php echo $gplus_html; ?>
    <?php echo $pinterest_html; ?>
    <?php echo $su_html; ?>
</div>