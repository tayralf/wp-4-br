<div class="order-box-2"<?php echo $box_style; ?>>
	<div class="order-box-2-internal cf">
		<div class="order-box-header">
			<img alt="" src="<?php echo OP_ASSETS_URL.'images/order_box/titles_2/'.$title ?>" />
		</div>
							
		<div class="order-box-content">
        <?php echo $content ?>
		</div>
	</div>
</div>