<div class="order-box-3"<?php echo $box_style; ?>>
	<div class="order-box-3-internal cf">
		<div class="order-box-header">
			<h2><img alt="" src="<?php echo OP_ASSETS_URL ?>images/order_box/green-tick.png" /> <?php echo $title ?></h2>
		</div>
							
		<div class="order-box-content">
			<?php echo $content ?>
		</div>
	</div>
</div>