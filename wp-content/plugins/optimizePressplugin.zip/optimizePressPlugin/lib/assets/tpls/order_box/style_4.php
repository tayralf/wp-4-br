<div class="order-box-4"<?php echo $box_style; ?>>
	<div class="order-box-4-internal cf">
		<div class="order-box-content">
        	<?php echo $content ?>
		</div>
	</div>
</div>