<div class="order-box-1"<?php echo $box_style; ?>>
	<div class="order-box-header">
		<h2><img alt="" src="<?php echo OP_ASSETS_URL.'images/order_box/titles_1/'.$title ?>" /></h2>
		<img alt="" src="<?php echo OP_ASSETS_URL.'images/order_box/headers_1/'.$header ?>" />
	</div>
	<div class="order-box-content">
        <?php echo $content ?>
	</div>
</div>