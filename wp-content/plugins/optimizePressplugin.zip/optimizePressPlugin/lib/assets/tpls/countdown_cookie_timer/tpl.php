<div id="<?php echo $id; ?>" class="countdown-cookie-timer countdown-cookie-timer-style-<?php echo $style; ?>"<?php echo (!empty($end_date) ? ' data-end="'.$end_date.'"' : '') ?><?php echo (!empty($redirect_url) ? ' data-redirect-url="'.$redirect_url.'"' : '') ?>>
    <div id="countdownTimer"></div>
</div>